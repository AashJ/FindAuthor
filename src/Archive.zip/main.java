/**
 * The main class tests the nextToken() method
 * and the parseDocument() method in the document
 * class. Does so by passing a string into each test.
 * To verify if the scanner.nextToken() method is working,
 * the class prints all of the tokens in the class.
 * To verify if the parseDocument() method is working,
 * the class prints all of the tokens in each sentence,
 * for each sentence. 
 */
import java.io.StringReader;


public class main 
{
	public static void main(String[] args)
	{
		//String to test the document
		StringReader documentTest = new StringReader("This is a document, collection of sentences. Does this throw out the correct things?"
				+ "Testing for the spearation of sentences! This works.");
		//Scanner to test the document
		Scanner dScanner = new Scanner(documentTest);
		//String to test the scanner
		StringReader scannerTest = new StringReader("   This is a string )(&)(*@!.   ");
		//Scanner Test
		System.out.println("Scanner Test:");
		Scanner  tScanner = new Scanner(scannerTest);
		for (int i = 0; i < 25; i++)
		{
			System.out.println(tScanner.nextToken().toString());
		}
		System.out.println("\n Document Test 1: \n");
		//Document Test
		Document d = new Document(dScanner);
		d.parseDocument();
		for (int i = 0; i < d.getSentenceCollection().size(); i++)
		{
			System.out.println(d.getSentenceCollection().get(i));
		}
		
		/**
		 * This dialogue from Shakespeare's "Hamlet" is all one sentence,
		 * and should therefore be returned in one line.
		 */
		StringReader docTestTwo = new StringReader
				("To be, or not to be, that is the question— "
				+ "Whether 'tis Nobler in the mind to suffer"
				+ " The Slings and Arrows of outrageous Fortune,"
				+ "Or to take Arms against a Sea of troubles,"
				+ " And by opposing, end them?");
		Scanner dScannerTwo = new Scanner(docTestTwo);
		Document dTwo = new Document(dScannerTwo);
		System.out.println("\n Document Test 2: \n" );
		dTwo.parseDocument();
		for (int k = 0; k < dTwo.getSentenceCollection().size(); k++)
		{
			System.out.println(dTwo.getSentenceCollection().get(k));
		}
	}
}
